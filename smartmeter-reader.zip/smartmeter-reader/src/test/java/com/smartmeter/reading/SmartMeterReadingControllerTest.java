package com.smartmeter.reading;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.isA;
import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.util.NestedServletException;

import com.google.gson.Gson;
import com.smartmeter.reading.controller.ReadingsController;
import com.smartmeter.reading.exception.MeterReadNotFoundException;
import com.smartmeter.reading.model.CustomerReading;
import com.smartmeter.reading.repository.ReadingsRepository;
import com.smartmeter.reading.service.ReadingsService;
import com.smartmeter.reading.service.impl.ReadingsServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("test")
@SpringBootTest(classes = SmartMeterReadingApplication.class)
public class SmartMeterReadingControllerTest {

	@Autowired
	private ReadingsService readingsService;

	@Autowired
	private ReadingsRepository readingsRepository;

	private ReadingsController readingsController;
	MockMvc mockMvc;

	@Before
	public void setUp() {
		readingsRepository.deleteAll();
		readingsController = new ReadingsController();
		readingsService = new ReadingsServiceImpl(readingsRepository);
		readingsController.setReadingsService(readingsService);
		mockMvc = MockMvcBuilders.standaloneSetup(readingsController).build();
	}

	/*
	 * This test verifies whether the received customer readings matches the passed
	 * ones for the given account number
	 */
	@Test
	public void testGetCustomerReadings() throws Exception {
		buildSampleReadingDetails(1234644L, 6189320304L, 9122233234L, 1555L, 690L);
		MvcResult mvcresult = mockMvc
				.perform(get("/api/smart/reads/1234644").contentType(MediaType.APPLICATION_JSON).content("{}"))
				.andExpect(status().isOk()).andReturn();
		CustomerReading reading = new Gson().fromJson(mvcresult.getResponse().getContentAsString(),
				CustomerReading.class);
		assertThat(reading).isNotNull();
		assertTrue(reading.getElecSmartRead().equals(1555L));
		assertTrue(reading.getGasSmartRead().equals(690L));
	}

	/*
	 * Sample Smart meter readings for tests
	 */
	private void buildSampleReadingDetails(Long accountNumber, Long gasId, Long elecId, Long elecSmartRead,
			Long gasSmartRead) throws Exception {

		CustomerReading customerReading = new CustomerReading();
		customerReading.setAccountNumber(accountNumber);
		customerReading.setGasId(gasId);
		customerReading.setElecId(elecId);
		customerReading.setElecSmartRead(elecSmartRead);
		customerReading.setGasSmartRead(gasSmartRead);

		readingsRepository.save(customerReading);
	}

	@Rule
	public ExpectedException expectedException = ExpectedException.none();

	/*
	 * This test expects both the exception thrown and the exception cause for a
	 * incorrect account number and also checks for the expected message
	 */
	@Test
	public void getCustomerReadingstestWithExceptions() throws Exception {

		expectedException.expect(NestedServletException.class);
		expectedException.expectCause(isA(MeterReadNotFoundException.class));

		MvcResult mvcresult = mockMvc
				.perform(get("/api/smart/reads/123").contentType(MediaType.APPLICATION_JSON).content("{}")).andReturn();

		assertThat(mvcresult.getResolvedException().getMessage())
				.isEqualTo("Meter Readings not found for the account number 123");
	}
}
