package com.smartmeter.reading.model;

import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Table;

@Entity
@Table(name = "readings")
public class CustomerReading {

	@Id
	@GeneratedValue
	private Long Id;

	@Column(name = "ACCOUNT_NUMBER")
	private Long accountNumber;

	@Column(name = "GAS_ID")
	private Long gasId;

	@Column(name = "ELEC_ID")
	private Long elecId;

	@Column(name = "ELEC_SMART_READ")
	private Long elecSmartRead;

	@Column(name = "GAS_SMART_READ")
	private Long gasSmartRead;

	public Long getId() {
		return Id;
	}

	public void setId(Long id) {
		Id = id;
	}

	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Long getGasId() {
		return gasId;
	}

	public void setGasId(Long gasId) {
		this.gasId = gasId;
	}

	public Long getElecId() {
		return elecId;
	}

	public void setElecId(Long elecId) {
		this.elecId = elecId;
	}

	public Long getElecSmartRead() {
		return elecSmartRead;
	}

	public void setElecSmartRead(Long elecSmartRead) {
		this.elecSmartRead = elecSmartRead;
	}

	public Long getGasSmartRead() {
		return gasSmartRead;
	}

	public void setGasSmartRead(Long gasSmartRead) {
		this.gasSmartRead = gasSmartRead;
	}

}
