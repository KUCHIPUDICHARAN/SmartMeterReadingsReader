package com.smartmeter.reading;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartMeterReadingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartMeterReadingApplication.class, args);
	}

}
