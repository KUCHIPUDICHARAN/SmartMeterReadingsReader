package com.smartmeter.reading.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smartmeter.reading.exception.MeterReadNotFoundException;
import com.smartmeter.reading.model.CustomerReading;
import com.smartmeter.reading.service.ReadingsService;

@RestController
@RequestMapping("/api/smart")
public class ReadingsController {

	private static final Logger LOGGER = LoggerFactory.getLogger(ReadingsController.class);

	@Autowired
	private ReadingsService readingsService;

	public void setReadingsService(ReadingsService readingsService) {
		this.readingsService = readingsService;
	}

	/*
	 * This method maps the requests to retrieve all customer readings
	 */
	@GetMapping("/reads")
	public List<CustomerReading> getCustomerReadings() {
		List<CustomerReading> customerReadings = readingsService.retrieveReadings();
		return customerReadings;
	}

	/*
	 * This method maps the requests to retrieve meter reading associated with the
	 * requested account number
	 */
	@GetMapping("/reads/{accountNumber}")
	public ResponseEntity<CustomerReading> getCustomerReading(
			@PathVariable(name = "accountNumber") Long accountNumber) {

		LOGGER.info("Requested readings for the account number \"{}\" ", accountNumber);

		CustomerReading customerReading = readingsService.getCustomerReading(accountNumber);

		if (customerReading != null) {
			return ResponseEntity.ok().body(customerReading);
		} else {
			throw new MeterReadNotFoundException("Meter Readings not found for the account number " + accountNumber);
		}
	}

	/*
	 * This method maps the requests to create customer reading
	 */
	@PostMapping("/reads")
	public void recordCustomerReading(@RequestBody final CustomerReading customerReading) {
		readingsService.saveCustomerReading(customerReading);
	}

}
