package com.smartmeter.reading.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smartmeter.reading.model.CustomerReading;
import com.smartmeter.reading.repository.ReadingsRepository;
import com.smartmeter.reading.service.ReadingsService;

@Service
public class ReadingsServiceImpl implements ReadingsService {

	private ReadingsRepository readingsRepository;

	@Autowired
	public ReadingsServiceImpl(ReadingsRepository readingsRepository) {
		this.readingsRepository = readingsRepository;
	}

	@Override
	public List<CustomerReading> retrieveReadings() {
		return readingsRepository.findAll();
	}

	@Override
	public CustomerReading getCustomerReading(Long accountNumber) {
		return readingsRepository.findByAccountNumber(accountNumber);
	}

	@Override
	public void saveCustomerReading(CustomerReading customerReading) {
		readingsRepository.save(customerReading);
	}

}
