package com.smartmeter.reading.service;

import java.util.List;

import com.smartmeter.reading.model.CustomerReading;

public interface ReadingsService {

	public List<CustomerReading> retrieveReadings();

	public CustomerReading getCustomerReading(Long accountNumber);

	public void saveCustomerReading(CustomerReading customerReading);

}
