package com.smartmeter.reading.exception;

public class MeterReadNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public MeterReadNotFoundException(String message) {
		super(message);
	}

	public MeterReadNotFoundException(String message, Throwable e) {
		super(message, e);
	}

}
