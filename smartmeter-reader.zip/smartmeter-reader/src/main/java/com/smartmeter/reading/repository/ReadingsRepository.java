package com.smartmeter.reading.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.smartmeter.reading.model.CustomerReading;

@Repository
public interface ReadingsRepository extends JpaRepository<CustomerReading, Long> {

	CustomerReading findByAccountNumber(Long accountNumber);

}
